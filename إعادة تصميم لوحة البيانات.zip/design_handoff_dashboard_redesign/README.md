# Handoff: إعادة تصميم داشبورد محلات العائلة (financial dashboard)

## Overview
Redesign proposal for a static HTML/CSS/vanilla-JS financial dashboard (revenue, expenses, suppliers, customers, profit scenarios). Goals: reduce information density, replace popup modals with inline expand/collapse, add compare/search/custom-range/auto-alert patterns, and apply a new color system. Target codebase: **GitHub repo `fo0ouad/taqrir-ribhiya`, branch `gh-pages`** — a plain HTML/CSS/JS site (no build step, no framework). Implement directly in that repo's existing files, not in a new stack.

## About the Design Files
The bundled file `Redesign-Proposal-reference.html` is a **design reference** (an interactive mockup), not production code to copy verbatim. It uses a small internal templating/state system for the mockup only. The task is to **recreate this design directly in the target repo's real files**:
- `index.html`, `css/style.css`
- `js/tables.js`, `js/menSuppliers.js`, `js/purchases.js`, `js/monthlyReports.js`, `js/customers.js`, `js/analyticalReport.js`, `js/profitScenario.js`, `js/womenSuppliers.js`, `js/utils.js`, `js/charts.js`, `js/auth.js`
- `data.js` (data + calculation logic) must NOT change — all existing computations (15% margin, cash surplus, supplier diff formulas, etc.) stay exactly as they are; only presentation/layout/interaction changes.
- `profit-first.html`, `upload.html`, `login.html` get the new visual system applied (colors, type, cards) but keep their current functional flow.

## Fidelity
**Mixed**:
- **High-fidelity**: the color system, typography, sidebar navigation/IA, and the 4 priority screens shown fully mocked — الملخص التنفيذي (Executive Summary), التقارير الشهرية (Monthly Reports), المصاريف التفصيلية (Detailed Expenses), التقرير التحليلي (Analytical Report). Recreate these pixel-close: exact colors, spacing, card structure, interaction pattern.
- **Low-fidelity / conceptual**: the remaining 6 tabs (المشتريات, موردين الرجالي, موردين النسائي, عملاء النسائي, سيناريو الربحية, تقييم Profit First) are described as **concept notes only** (see "Other tabs" section below), not pixel mockups. Apply the same design system (colors, card style, expand-instead-of-modal pattern, sidebar IA) to their EXISTING current layout/content — do not invent new content for them.

## Information Architecture (the main structural change)
Replace the current horizontal pill-tab bar (9 tabs in one row) with a **grouped left sidebar** (RTL: sidebar sits on the right edge of the screen):
- **الرئيسية**: الملخص التنفيذي
- **التقارير**: التقارير الشهرية، المصاريف التفصيلية، المشتريات، التقرير التحليلي
- **الأطراف التجارية**: موردين الرجالي، موردين النسائي، عملاء النسائي
- **الأدوات والتخطيط**: سيناريو الربحية، تقييم Profit First (currently a separate `profit-first.html` page reached via an external link in the tab bar — convert it into a real in-app tab/section inside this group so navigation is a single consistent experience)

Sidebar top: logo mark + title + a persistent global search input (search across months/suppliers/customers/categories — new capability, needs to be wired to existing data structures in `data.js`).
Sidebar bottom: "رفع بيانات" (link to `upload.html`, styled as a filled pill button) and "خروج" (logout, existing `logout()` function in `js/auth.js`).

### Mobile (≤ ~640px)
Sidebar collapses to a **bottom tab bar** with 5 icons (one per group above). Tapping a group navigates to its first screen; if the group has more than one screen, show a horizontal scrollable chip strip at the top of the content area to switch between that group's screens. See the reference file's "معاينة الجوال" toggle for the exact interaction (button in the top strip switches the whole shell into a 390px-wide phone frame with this layout).

## New Interaction Patterns (apply wherever the current site uses a modal or is one of the pain points)
1. **Expand instead of modal**: every table row that currently opens `#modal-overlay` (month detail, expense category × month cell, supplier detail, customer detail) should instead expand an inline detail panel directly below/within the row. Remove the modal for these cases entirely (`openMonthDetail`, expense modal, etc. in `js/tables.js` / `js/analyticalReport.js` need to render inline instead of populating `#modal-body`).
2. **Compare mode**: a toggle button (top-right of a screen) that shows two periods (e.g., two months or two years) side by side with delta badges. Add to الملخص التنفيذي first; consider for المشتريات and التقرير التحليلي.
3. **Custom date range**: replace the "الكل / 2025 / 2026" year-only filters with a date-range control that can also do arbitrary month-to-month ranges. Keep the quick year buttons as presets inside the same control.
4. **Automatic alerts**: any KPI card or table row for the most recent month with a negative "ربح" (profit) or negative cash surplus should surface an automatic red alert banner (see summary screen "تنبيه تلقائي" reference) — compute this from data already available in `data.js`, no new backend needed.
5. **Unified search**: sidebar search box should filter/jump across months, supplier names, customer names, and expense categories (client-side, since all data is already loaded via `data.js`).

## Design Tokens
### Colors (from Numerro's BI dashboard color-role framework, adapted to this brand — confirmed with the client)
| Role | Hex | Usage |
|---|---|---|
| Background | `#F5F7FB` | page background, filter/slicer backgrounds, subheaders |
| Box | `#FFFFFF` | card backgrounds, sidebar, box outlines |
| Box outline / borders | `#E7E9EE` | all card/table borders |
| Text | `#33394C` | headings, primary values, body text |
| Muted text | `#64748B` / `#94A3B8` | secondary labels, captions |
| Primary 1 (data) | `#4E7CFF` | logo, active nav state, first chart series, primary buttons/accents |
| Primary 2 (data) | `#7033FF` | second chart series, secondary buttons/accents |
| Primary 3 (data) | `#F65164` | third chart series / category color (used for chart data only) |
| Success (functional — profit only) | `#15803D` text / `#F0FDF4` bg | positive numbers only |
| Danger (functional — loss/alerts only) | `#B91C1C` text / `#FEF2F2` bg (border `#FCA5A5`) | negative numbers and auto-alerts only |

**Rule**: keep functional green/red strictly for financial polarity (profit vs. loss) and alerts. Do not use green/red as decorative brand accents elsewhere — use Primary 1/2/3 for that.

### Typography
- Font: **IBM Plex Sans Arabic** (Google Fonts, weights 400/500/600/700/800), loaded via `<link>` in `<head>`, replacing the current `'Segoe UI', Tahoma, Arial, sans-serif` stack.
- Headings: 800 weight. Body/labels: 700 weight for emphasis, 400/500 for regular text.
- Numeric values keep tabular alignment (already true of the font).

### Spacing / shape
- Card radius: 12px. Pill radius (buttons/chips/badges): 999px. Small controls: 8px.
- Card border: `1px solid #E7E9EE`, no drop shadow (flat, bordered cards — not the old `box-shadow: 0 2px 8px rgba(0,0,0,0.06)`).
- Standard card padding: 16–18px.
- Grid gaps: 12–16px.

## Screens (priority — build these pixel-close)

### 1. الملخص التنفيذي (Executive Summary)
- Top row: page title + subtitle (date range) on the right, custom-range pill + "وضع المقارنة" toggle button on the left.
- Auto-alert banner (danger colors) when latest month is a loss, with exact numbers.
- Compare panel (toggle-shown): two-column comparison of same month across years, with revenue/profit deltas.
- KPI row: 5 cards (existing metrics: إجمالي الإيرادات, صافي النتيجة التشغيلية, أشهر الربح, مجموع الخسائر, مجموع الأرباح) — flat white bordered cards, no colored left border, colored numeric value only.
- Charts: 2-up grid — line chart (revenue vs. 15% margin, both years) using Primary 1 + Primary 2; bar chart (monthly profit/loss) colored green/red per bar by sign. Keep Chart.js (already a dependency).
- Table: monthly summary — light `#F5F7FB`/white header row (no more dark navy header bar), each row expands inline (no modal) to show margin/daily avg/cash surplus/supplier figures in a small grid.

### 2. التقارير الشهرية (Monthly Reports)
- Month switcher: prev/next arrows + a filled pill showing the current month (Primary 1 background).
- Branch performance mini-grid (فرع 1 / فرع 2 / الفارق) — already exists in `js/monthlyReports.js`, just restyle.
- Expense line items list: existing expand/collapse toggle behavior (`.monthly-expense-row` / `.inline-toggle` already implements this pattern in the current code) — keep the interaction, restyle to new tokens.

### 3. المصاريف التفصيلية (Detailed Expenses)
- KPI row (4 cards): إجمالي المصاريف, أكبر فئة, أعلى شهر مصاريف, متوسط شهري.
- Category filter chips (الكل / مصاريف العائلة / رسوم المرافقين / فئة أخرى — real categories come from `data.js`).
- **Default view**: ranked horizontal bar list of categories (largest first) — replaces the always-visible 16-column category×month matrix as the primary view.
- Full category×month matrix (`#exp-table`) stays available behind a "عرض الجدول الكامل" button for power users, not shown by default.

### 4. التقرير التحليلي (Analytical Report)
- The existing sticky in-page sub-nav (`.report-subnav`) becomes a compact horizontal pill strip at the top of the content area (since the sidebar now owns top-level nav).
- Equation card pattern (e.g. "ربح = هامش 15% − المصاريف") — bordered boxes with an operator between them, kept from current `.report-cogs-equation` concept, restyled to new tokens, negative results shown in danger colors.
- Highlight boxes (best/worst month etc.) — solid tint background (no left border accent bar), functional green/red only when the content is genuinely positive/negative.

## Other tabs (concept only — apply system, keep current content/logic)
- **المشتريات**: add KPI row (total/avg/max) above existing table; add a supplier-paid line on the same chart as purchases for direct comparison; convert modal detail (if any) to expand-in-place.
- **موردين الرجالي**: convert the 4-column supplier card grid into a table with an expandable row (name + amount owed + payment progress bar in the collapsed row; invoices in the expanded detail). Status filters become chips.
- **موردين النسائي**: merge the supplier table and the separate "خطة سداد الديون" section into one table via expandable rows — no separate section. Priority column becomes a colored status badge.
- **عملاء النسائي**: same merge pattern as women-suppliers, applied to the customer table + collection plan. Default sort by priority (high first).
- **سيناريو الربحية**: keep all existing calculator logic/interaction as-is (`js/profitScenario.js`) — only restyle colors/cards/typography to the new tokens.
- **تقييم Profit First**: convert `profit-first.html` from a standalone linked page into a tab inside the "الأدوات والتخطيط" sidebar group; restyle to match.

## State Management
Client-side only, no backend changes:
- `activeScreen` (which sidebar item is selected) — replaces current `switchTab()`/`.tab-content.active` mechanism, same idea, new markup.
- Per-table `expandedRowId` (which row's detail panel is open) — replaces the modal-open state.
- `compareOn` boolean and the two periods being compared.
- `activeCategory` / search query for filtering.
- `mobilePreview`-equivalent is just a CSS breakpoint in production (the reference file's toggle was only for demoing the mobile layout inside a desktop preview — real implementation should use a real `@media` breakpoint, not a manual toggle).

## Assets
No new image assets. Font: IBM Plex Sans Arabic (Google Fonts CDN). Charts: existing Chart.js 4.4.0 CDN dependency, unchanged.

## Files in this bundle
- `Redesign-Proposal-reference.html` — the interactive design reference described above (open directly in a browser; click sidebar items to see each screen, toggle "وضع المقارنة" and "معاينة الجوال" to see those states).
